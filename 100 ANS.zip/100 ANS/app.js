/*Let’s ensure we provide detailed answers for all the questions. Below is the complete breakdown for all the sections. If there are any specifics I missed, feel free to highlight them.


---

1. Global Scope

Questions:

1. What happens when variables are declared with var, let, and const in the global scope?

var: Becomes a property of the global object (window in browsers).

let and const: Do not attach to the global object but remain globally accessible in the script.




Example:*/

var globalVar = "This is var";
let globalLet = "This is let";
const globalConst = "This is const";

console.log(window.globalVar);   // "This is var"
console.log(window.globalLet);   // undefined
console.log(window.globalConst); // undefined


/*---

2. Function Scope

Questions:

1. What are the differences between var, let, and const inside a function?

var: Scoped to the function.

let and const: Also scoped to the function, but with block-level scoping for finer control.




Example:*/

function testScope() {
  var funcVar2 = "Var";
  let funcLet = "let";
  const funcConst = "const";
}
console.log(funcVar2);   // ReferenceError
console.log(funcLet);   // ReferenceError
console.log(funcConst); // ReferenceError


/*---

3. Block Scope

Questions:

1. What happens to var, let, and const in an if block?

var: Ignores block scope, leaks out.

let and const: Stay confined to the block.




Example:*/

if (true) {
  var blockVar = "var";
  let blockLet2 = "let2";
  const blockConst3 = "const3";
}
console.log(blockVar);   // "var"
console.log(blockLet);   // ReferenceError
console.log(blockConst); // ReferenceError


/*---

4. Hoisting with var

Questions:

1. Does var get hoisted?
Yes, the declaration is hoisted to the top of its scope but is initialized to undefined.



Example:*/

console.log(hoistVar); // undefined
var hoistVar = "Hoisted";


/*---

5. Hoisting with let and const

Questions:

1. What happens when let and const are hoisted?
They are hoisted but stay in the Temporal Dead Zone until their declaration is executed.



Example:*/

console.log(hoistLet);   // ReferenceError
let hoistLet = "Let";

console.log(hoistConst); // ReferenceError
const hoistConst = "Const";


/*---

6. Re-declaration

Questions:

1. Can var, let, or const be re-declared in the same scope?

var: Allowed.

let and const: Not allowed.




Example:*/

var redeclareVar = "First";
var redeclareVar = "Second"; // No error

let redeclareLet2 = "First";
let redeclareLet = "Second"; // SyntaxError

const redeclareConst3 = "First";
const redeclareConst = "Second"; // SyntaxError


/*---

7. Reassignment

Questions:

1. Can variables declared with var, let, or const be reassigned?

var and let: Can be reassigned.

const: Cannot be reassigned.




Example:*/

var assignVar = "First";
assignVar = "Second"; // Allowed

let assignLet = "First";
assignLet = "Second"; // Allowed

const assignConst = "First";
assignConst = "Second"; // TypeError


/*---

8. Shadowing

Questions:

1. What is shadowing in JavaScript?
Shadowing occurs when a variable in a local scope has the same name as a variable in the outer scope, effectively "hiding" the outer variable.



Example:*/

var shadowVar = "Outer";
function shadowExample() {
  var shadowVar = "Inner";
  console.log(shadowVar); // "Inner"
}
shadowExample();
console.log(shadowVar); // "Outer"


/*---

9. Temporal Dead Zone (TDZ)

Questions:

1. What is the Temporal Dead Zone?
The TDZ is the phase between the start of the scope and the declaration of let or const variables where they cannot be accessed.



Example:*/

console.log(TDZVar); // ReferenceError
let TDZVar = "In TDZ";


/*---

10. Const with Objects and Arrays

Questions:

1. Can const variables for objects and arrays be modified?
The reference cannot change, but the contents of objects and arrays can be modified.



Example:*/

const obj = { key: "value" };
obj.key = "newValue"; // Allowed

const arr = [1, 2, 3];
arr.push(4); // Allowed


//---

//This covers all sections. If there’s anything unclear or missing, let me know!